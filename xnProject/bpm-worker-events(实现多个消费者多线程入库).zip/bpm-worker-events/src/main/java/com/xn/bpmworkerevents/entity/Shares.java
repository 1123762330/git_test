package com.xn.bpmworkerevents.entity;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * @Author: zly
 * @Date: 2019/5/31 10:36
 */
@Data
public class Shares implements Serializable {
    private Long id;

    private String rem_host;

    private String username;

    private Object our_result;

    private Object upstream_result;

    private String reason;

    private String solution;

    private Double difficulty;

    private Date time;

    private static final long serialVersionUID = 1L;
}