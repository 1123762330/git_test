package com.xn.bpmworkerevents.controller;

import com.google.gson.Gson;
import com.xn.bpmworkerevents.config.Configs;
import com.xn.bpmworkerevents.entity.PoolWorker;
import com.xn.bpmworkerevents.entity.Shares;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * FileName:       ConsumerRunnable
 * Author:         Administrator
 * Date:           2019/5/20 16:44
 * Description:
 */

public class ConsumerRunnable implements Runnable {
    private ExecutorService executors;

    // 每个线程维护私有的KafkaConsumer实例
    private KafkaConsumer<String, String> consumer;

    public ConsumerRunnable(Configs configs) {
        Map<String, Object> properties = new HashMap<String, Object>();
        properties.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, configs.getBrokerList());//kafka地址
        properties.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, configs.getCommit());//自动提交
        properties.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, configs.getInterval());//自动提交间隔
        properties.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, configs.getTimeout());//session过期时间
        properties.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, configs.getKeyzer());//key序列化
        properties.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, configs.getValuezer());//value序列化
        properties.put(ConsumerConfig.GROUP_ID_CONFIG, configs.getGroupId());//group id
        properties.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, configs.getReset());
        properties.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, configs.getMaxRecords());
        this.consumer = new KafkaConsumer<>(properties);
        List<String> topic = configs.getTopic();
        consumer.subscribe(topic);
    }

    //外层的是多个消费者,此类是一个消费者里的一个单线程,想实现外层多个消费者,内层多线程

    @Override
    public void run() {
        executors = new ThreadPoolExecutor(8, 8, 0L, TimeUnit.MILLISECONDS,
                new ArrayBlockingQueue<>(1000), new ThreadPoolExecutor.CallerRunsPolicy());
        while (true) {
            ConsumerRecords<String, String> records = consumer.poll(200);
            ArrayList<ConsumerRecord> arrayList = new ArrayList<>();
            for (final ConsumerRecord record : records) {
                arrayList.add(record);

            }
            //System.out.println("======"+arrayList.size());
            if(arrayList.size()!=0){
                executors.submit(new Worker(arrayList));
            }
        }
    }
}
