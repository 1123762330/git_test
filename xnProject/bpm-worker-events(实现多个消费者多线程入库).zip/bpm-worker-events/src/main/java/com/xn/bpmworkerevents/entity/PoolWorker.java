package com.xn.bpmworkerevents.entity;

import lombok.Data;

@Data
public class PoolWorker {
    private Integer account_id;

    private String username;

    private String password;

    private Float difficulty;

    private Boolean monitor;

    private String last_access_time;
}