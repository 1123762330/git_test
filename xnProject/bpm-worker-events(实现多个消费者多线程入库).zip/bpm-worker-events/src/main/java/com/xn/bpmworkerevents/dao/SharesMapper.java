package com.xn.bpmworkerevents.dao;

import com.xn.bpmworkerevents.entity.Shares;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Author:     zly 
 * @Date:    2019/5/31 10:36
 */
@Mapper
@Repository
public interface SharesMapper {
    int deleteByPrimaryKey(Long id);

    int insert(Shares record);

    int insertSelective(Shares record);

    Shares selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Shares record);

    int updateByPrimaryKey(Shares record);

    void insertBatchShares(List<Shares> list);
}