package com.xn.bpmworkerevents.controller;

import com.google.gson.Gson;
import com.xn.bpmworkerevents.config.SpringUtils;
import com.xn.bpmworkerevents.dao.PoolWorkerMapper;
import com.xn.bpmworkerevents.dao.SharesMapper;
import com.xn.bpmworkerevents.entity.PoolWorker;
import com.xn.bpmworkerevents.entity.Shares;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

//业务逻辑层
public class Worker implements Runnable {

    private SharesMapper sharesMapper;

    private PoolWorkerMapper poolWorkerMapper;

    private List recordList;

    private final static Logger logger = LoggerFactory.getLogger(Worker.class);

    public Worker(List list) {
        this.recordList = list;
        this.sharesMapper = SpringUtils.getBean(SharesMapper.class);
        this.poolWorkerMapper=SpringUtils.getBean(PoolWorkerMapper.class);
    }

    @Override
    public void run() {

        List<Shares> sharesList = new ArrayList<>();
        List<PoolWorker> poolWorkersList = new ArrayList<>();
        for (int i = 0; i < recordList.size(); i++) {
            ConsumerRecord record = (ConsumerRecord) recordList.get(i);
            System.out.println("数据是:"+record);
            if ("MposShareTopic".equals(record.topic())) {
                Optional<?> kafkaMessage = Optional.ofNullable(record.value());
                if (kafkaMessage.isPresent()) {
                    Object object = kafkaMessage.get();
                    Gson gson = new Gson();
                    Shares shares = gson.fromJson(object.toString(), Shares.class);
                    sharesList.add(shares);
                }
            }

            if ("BtcCommonEvents".equals(record.topic())) {
                Optional<?> kafkaMessage = Optional.ofNullable(record.value());
                if (kafkaMessage.isPresent()) {
                    //从消息中获取Object对象
                    Object object = kafkaMessage.get();
                    logger.info("BtcCommonEvents查询到的数据:"+object);
                    //System.out.println("查询到的数据:"+object);
                    //JSONObject jsonObject = JSONObject.parseObject(object.toString());
                    //获取连接类型
                    //String type = jsonObject.getString("type");
                    Gson gson = new Gson();
                    PoolWorker poolWorker = gson.fromJson(object.toString(), PoolWorker.class);
                    poolWorkersList.add(poolWorker);
                }
            }
        }

        try {
            if (sharesList.size() != 0) {
                sharesMapper.insertBatchShares(sharesList);
                logger.info("线程名称是:" + Thread.currentThread().getName() +"sharesList共" + sharesList.size()+"条数据");
                logger.info("Shares入库成功!");
            } else {
                logger.info("sharesList暂无新数据!");
            }
        } catch (Exception e) {
            //e.printStackTrace();
            logger.info("Shares数据已存在!");
        }

        try {
            if (poolWorkersList.size() != 0) {
                poolWorkerMapper.insertPoolWorker(poolWorkersList);
                logger.info("poolWorker入库成功!");
            } else {
                logger.info("poolWorkersList暂无新数据!");
            }
        } catch (Exception e) {
            //e.printStackTrace();
            logger.info("poolWorker数据已存在!");
        }

    }

}