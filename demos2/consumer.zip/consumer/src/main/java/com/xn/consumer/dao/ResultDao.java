package com.xn.consumer.dao;

import com.xn.consumer.domain.Result;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Mapper
public interface ResultDao {
    //查询方法
    public List<Result> findMessageList() ;

    //save方法
    public Integer saveMessage(@Param("user_id") Integer userId, @Param("user_name") String username);

}
